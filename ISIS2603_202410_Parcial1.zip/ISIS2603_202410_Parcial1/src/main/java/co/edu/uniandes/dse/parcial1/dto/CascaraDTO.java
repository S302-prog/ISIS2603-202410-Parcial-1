package co.edu.uniandes.dse.parcial1.dto;

public class CascaraDTO {

}
