package co.edu.uniandes.dse.parcial1.repositories;

import org.springframework.stereotype.Repository;

@Repository
public interface CascaraRepository {

}
